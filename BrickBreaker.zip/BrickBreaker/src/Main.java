import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		
		JFrame o = new JFrame();
		o.setBounds(900, 200, 700, 600);
        o.setTitle("Brick Breaker Game");
        o.setVisible(true);
        o.setResizable(false);
        o.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Game g = new Game();
        o.add(g);
	}

}
